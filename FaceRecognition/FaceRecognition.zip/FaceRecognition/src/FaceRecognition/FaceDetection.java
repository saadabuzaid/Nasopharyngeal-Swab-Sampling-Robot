package FaceRecognition;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

public class FaceDetection {
    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        String ImgFile= "D:\\CE301- Y3 Project\\FaceRecognition\\Images\\Kante.jpg";
        Mat src= Imgcodecs.imread(ImgFile);

        String XmlFile="D:\\CE301- Y3 Project\\FaceRecognition\\Xml\\haarcascadeNose.xml";
        CascadeClassifier cc= new CascadeClassifier(XmlFile);

        MatOfRect FaceDetection = new MatOfRect();
        cc.detectMultiScale(src,FaceDetection);
        System.out.println(String.format("Detected faces: %d",FaceDetection.toArray().length));

        for (Rect rect : FaceDetection.toArray()){
            Imgproc.rectangle(src, new Point(rect.x,rect.y),new Point(rect.x + rect.width,rect.y + rect.height), new Scalar(0,0,255), 3);
        }

        Imgcodecs.imwrite("D:\\CE301- Y3 Project\\FaceRecognition\\Images\\KanteOut.jpg", src);
        System.out.println("Image Detection Finished");
    }
}
